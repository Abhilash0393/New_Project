import random, string
import names

class functions():


    def generate_random_email(self):
        ''' This function Generates a random email address'''
        domains = [".com"]
        domain = (random.choice(domains))
        at = "@"
        user = ''.join([random.choice(string.ascii_letters) for n in range(10)])
        hosts = [ "gmail", "yahoo"]
        host= (random.choice(hosts))
        output = (user + at + host + domain)
        return output

    def generate_random_male_name(self):
        '''This function generates a random male first name'''
        output = names.get_first_name(gender='male')
        return output

    def generate_random_last_name(self):
        '''This function generates a random last name'''
        output = names.get_last_name()
        return output